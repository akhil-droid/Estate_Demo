"""
Data Loader for UK Estate Agency AI System
Loads CSV data from stage-specific folders automatically
"""

import os
import csv
from typing import Dict, List, Any, Optional

# ============================================================================
# STAGE-SPECIFIC FILE MAPPINGS
# ============================================================================

STAGE_1_FILES = {
    "leads": "leads.csv",
    "buyers": "buyers.csv",
    "vendors": "vendors.csv",
    "properties": "properties.csv",
    "enquiries": "enquiries.csv",
    "viewings": "viewings.csv",
    "offers": "offers.csv",
    "communications": "communications.csv",
    "marketing_campaigns": "marketing_campaigns.csv",
    "financial_qualifications": "financial_qualifications.csv",
    "buyer_requirements": "buyer_requirements.csv",
    "workflow_paths": "workflow_paths.csv",
    "sub_tasks": "sub_tasks.csv",
    "agent_executions": "agent_executions.csv"
}

STAGE_2_FILES = {
    "valuations": "stage2_valuations.csv",
    "property_research": "stage2_property_research.csv",
    "cma_reports": "stage2_cma_reports.csv",
    "marketing_proposals": "stage2_marketing_proposals.csv",
    "valuation_visits": "stage2_valuation_visits.csv",
    "instructions": "stage2_instructions.csv",
    "workflow_paths": "stage2_workflow_paths.csv",
    "sub_tasks": "stage2_sub_tasks.csv",
    "agent_executions": "stage2_agent_executions.csv",
    "communications": "stage2_communications.csv"
}

# Shared tables that span multiple stages
SHARED_TABLES = ["vendors", "properties", "buyers"]

# ============================================================================
# CSV LOADING FUNCTIONS
# ============================================================================

def load_csv(filepath: str) -> List[Dict[str, Any]]:
    """Load a CSV file and return list of dictionaries"""
    records = []
    
    if not os.path.exists(filepath):
        print(f"  ⚠️ File not found: {filepath}")
        return records
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Convert values to appropriate types
                processed_row = {}
                for key, value in row.items():
                    # Skip None keys (can happen with malformed CSV)
                    if key is None:
                        continue
                    
                    # Handle None or empty values
                    if value is None or value == '':
                        processed_row[key] = None
                    # Only process strings
                    elif isinstance(value, str):
                        value_lower = value.lower().strip()
                        if value_lower == 'true':
                            processed_row[key] = True
                        elif value_lower == 'false':
                            processed_row[key] = False
                        else:
                            # Try to convert to number
                            try:
                                if '.' in value:
                                    processed_row[key] = float(value)
                                else:
                                    processed_row[key] = int(value)
                            except (ValueError, TypeError):
                                processed_row[key] = value
                    else:
                        # Keep non-string values as-is
                        processed_row[key] = value
                records.append(processed_row)
    except Exception as e:
        print(f"  ❌ Error loading {filepath}: {e}")
    
    return records


def load_stage_data(data_dir: str, stage: int) -> Dict[str, List[Dict]]:
    """Load all data for a specific stage"""
    data = {}
    
    # Determine stage folder and file mapping
    if stage == 1:
        stage_folder = os.path.join(data_dir, "Stage_1")
        file_mapping = STAGE_1_FILES
    elif stage == 2:
        stage_folder = os.path.join(data_dir, "Stage_2")
        file_mapping = STAGE_2_FILES
    else:
        print(f"  ⚠️ Stage {stage} not yet implemented")
        return data
    
    print(f"\n📂 Loading Stage {stage} data from: {stage_folder}")
    print("-" * 50)
    
    if not os.path.exists(stage_folder):
        print(f"  ❌ Stage folder not found: {stage_folder}")
        return data
    
    for table_name, filename in file_mapping.items():
        filepath = os.path.join(stage_folder, filename)
        records = load_csv(filepath)
        data[table_name] = records
        if records:
            print(f"  ✓ {filename}: {len(records)} records")
    
    return data


def load_all_data(data_dir: str = None) -> Dict[str, Dict[str, List[Dict]]]:
    """
    Load all data from all stages
    Returns: {
        "stage_1": {"leads": [...], "buyers": [...], ...},
        "stage_2": {"valuations": [...], "cma_reports": [...], ...},
        "shared": {"vendors": [...], "properties": [...], ...}
    }
    """
    if data_dir is None:
        data_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    
    data_dir = os.path.abspath(data_dir)
    
    print("\n" + "=" * 60)
    print("🏠 UK ESTATE AGENCY AI SYSTEM - Data Loader")
    print("=" * 60)
    
    all_data = {
        "stage_1": {},
        "stage_2": {},
        "shared": {}
    }
    
    # Load Stage 1 data
    all_data["stage_1"] = load_stage_data(data_dir, 1)
    
    # Load Stage 2 data
    all_data["stage_2"] = load_stage_data(data_dir, 2)
    
    # Extract shared tables (vendors, properties, buyers from Stage 1)
    for table in SHARED_TABLES:
        if table in all_data["stage_1"]:
            all_data["shared"][table] = all_data["stage_1"][table]
    
    # Calculate totals
    stage_1_total = sum(len(v) for v in all_data["stage_1"].values())
    stage_2_total = sum(len(v) for v in all_data["stage_2"].values())
    
    print("\n" + "-" * 50)
    print(f"📊 Stage 1: {stage_1_total} records")
    print(f"📊 Stage 2: {stage_2_total} records")
    print(f"📊 Total: {stage_1_total + stage_2_total} records")
    print("=" * 60)
    
    return all_data


def get_data_for_stage(all_data: Dict, stage: int) -> Dict[str, List[Dict]]:
    """
    Get combined data for a specific stage (stage data + shared data)
    """
    stage_key = f"stage_{stage}"
    
    if stage_key not in all_data:
        return {}
    
    # Combine stage-specific data with shared data
    combined = dict(all_data[stage_key])
    
    # Add shared tables
    for table_name, records in all_data.get("shared", {}).items():
        if table_name not in combined:
            combined[table_name] = records
    
    return combined


def get_data_for_subtask(all_data: Dict, sub_task_id: str) -> Dict[str, List[Dict]]:
    """
    Get the appropriate data based on sub-task ID
    Sub-task IDs are like "1.1.1", "2.1.2", etc.
    """
    # Extract stage from sub_task_id
    try:
        stage = int(sub_task_id.split(".")[0])
    except (ValueError, IndexError):
        stage = 1  # Default to stage 1
    
    return get_data_for_stage(all_data, stage)


def get_stage_summary(all_data: Dict, stage: int) -> Dict:
    """Get summary statistics for a stage"""
    stage_data = get_data_for_stage(all_data, stage)
    
    return {
        "stage": stage,
        "tables": {k: len(v) for k, v in stage_data.items()},
        "total_records": sum(len(v) for v in stage_data.values())
    }


def get_data_summary(all_data: Dict) -> Dict:
    """Get overall data summary"""
    return {
        "stage_1": get_stage_summary(all_data, 1),
        "stage_2": get_stage_summary(all_data, 2),
        "total_records": sum(
            sum(len(v) for v in stage_data.values()) 
            for stage_data in all_data.values()
        )
    }


# ============================================================================
# EXAMPLE QUERIES BY STAGE
# ============================================================================

EXAMPLE_QUERIES = {
    # Stage 1 examples
    "1.1.1": [
        "Process the new valuation request from Jessica Turner",
        "Handle the inbound lead LEAD-001 from website"
    ],
    "1.1.2": [
        "Log the door-knocking activity on Elm Street",
        "Process outbound prospecting results"
    ],
    "1.2.1": [
        "Process the Rightmove enquiry from Daniel Harris",
        "Handle new portal enquiry ENQ-001"
    ],
    "1.3.2": [
        "Verify financial status of buyer BUY-001",
        "Check AIP details for Michael Brown"
    ],
    "1.3.3": [
        "Find matching buyers for property PROP-001",
        "Run buyer matching for new listing"
    ],
    # Stage 2 examples
    "2.1.1": [
        "Research property data for VAL-001 at 15 Elm Street",
        "Pull Land Registry and EPC for PROP-001"
    ],
    "2.1.2": [
        "Generate CMA report for valuation VAL-001",
        "Prepare comparative market analysis for 15 Elm Street"
    ],
    "2.1.3": [
        "Create marketing proposal for VAL-001",
        "Prepare premium marketing package for Jessica Turner"
    ],
    "2.2.4": [
        "Present pricing for VAL-001 with CMA evidence",
        "Handle price negotiation for 15 Elm Street"
    ],
    "2.2.7": [
        "Process instruction signing for VAL-001",
        "Complete sole agency contract for Jessica Turner"
    ],
    "2.3.1": [
        "Send thank you email for VAL-001",
        "Generate post-appointment communication"
    ],
    "2.3.2": [
        "Follow up with vendor VAL-003 about decision",
        "Schedule nurture call for unrealistic vendor"
    ]
}


# ============================================================================
# TESTING
# ============================================================================

if __name__ == "__main__":
    # Test loading
    data = load_all_data()
    
    print("\n🧪 Testing stage-specific data access:")
    
    # Test Stage 1 access
    stage_1_data = get_data_for_stage(data, 1)
    print(f"\nStage 1 tables: {list(stage_1_data.keys())}")
    
    # Test Stage 2 access
    stage_2_data = get_data_for_stage(data, 2)
    print(f"Stage 2 tables: {list(stage_2_data.keys())}")
    
    # Test subtask-based access
    subtask_data = get_data_for_subtask(data, "2.1.1")
    print(f"\nData for subtask 2.1.1: {list(subtask_data.keys())}")
