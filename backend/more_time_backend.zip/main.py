"""
UK Estate Agency AI System - Main Application
FastAPI server with stage-aware data loading
"""

import os
import sys
from contextlib import asynccontextmanager

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(__file__))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from api import router as api_router, initialize_data
from config import HOST, PORT, DEBUG, DATA_DIR

# ============================================================================
# LIFESPAN HANDLER
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle startup and shutdown events"""
    # Startup
    print("\n" + "=" * 60)
    print("🏠 UK ESTATE AGENCY AI SYSTEM v2.0")
    print("=" * 60)
    
    # Check for stage folders
    data_dir = os.path.abspath(DATA_DIR)
    stage_1_dir = os.path.join(data_dir, "Stage_1")
    stage_2_dir = os.path.join(data_dir, "Stage_2")
    
    print(f"\n📂 Data directory: {data_dir}")
    print(f"   Stage_1 folder: {'✓ Found' if os.path.exists(stage_1_dir) else '❌ Not found'}")
    print(f"   Stage_2 folder: {'✓ Found' if os.path.exists(stage_2_dir) else '❌ Not found'}")
    
    # Initialize data
    initialize_data(data_dir)
    
    print("\n" + "=" * 60)
    print(f"🚀 Server running at http://{HOST}:{PORT}")
    print(f"📖 API Docs at http://{HOST}:{PORT}/docs")
    print("=" * 60 + "\n")
    
    yield
    
    # Shutdown (if needed)
    print("\n🛑 Server shutting down...")

# ============================================================================
# CREATE APP
# ============================================================================

app = FastAPI(
    title="UK Estate Agency AI System",
    description="Multi-stage workflow automation with AI agents",
    version="2.0.0",
    lifespan=lifespan
)

# ============================================================================
# CORS MIDDLEWARE
# ============================================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# INCLUDE API ROUTER
# ============================================================================

app.include_router(api_router)

# ============================================================================
# STATIC FILES & FRONTEND
# ============================================================================

frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")

# Mount static directories
if os.path.exists(os.path.join(frontend_dir, "css")):
    app.mount("/css", StaticFiles(directory=os.path.join(frontend_dir, "css")), name="css")

if os.path.exists(os.path.join(frontend_dir, "js")):
    app.mount("/js", StaticFiles(directory=os.path.join(frontend_dir, "js")), name="js")

if os.path.exists(os.path.join(frontend_dir, "assets")):
    app.mount("/assets", StaticFiles(directory=os.path.join(frontend_dir, "assets")), name="assets")

# ============================================================================
# ROOT ROUTE - SERVE FRONTEND
# ============================================================================

@app.get("/")
async def root():
    """Serve the frontend application"""
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "UK Estate Agency AI System API", "docs": "/docs"}

@app.get("/info")
async def info():
    """Get system information"""
    return {
        "name": "UK Estate Agency AI System",
        "version": "2.0.0",
        "stages_enabled": [1, 2],
        "data_structure": {
            "Stage_1": "Lead Generation & Customer Acquisition",
            "Stage_2": "Valuation Appointment"
        },
        "endpoints": {
            "api_docs": "/docs",
            "health": "/api/health",
            "plan": "/api/plan",
            "execute": "/api/execute",
            "data_summary": "/api/data/summary",
            "stage_data": "/api/data/stage/{stage_num}"
        }
    }

# ============================================================================
# RUN SERVER
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=HOST,
        port=PORT,
        reload=DEBUG,
        log_level="info"
    )
