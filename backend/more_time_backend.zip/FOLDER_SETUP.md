# Folder Setup Instructions

## Required Folder Structure

Your data folder should look like this:

```
C:\Users\mouni\uk_estate_agency_ai\data\
├── Stage_1\
│   ├── leads.csv
│   ├── buyers.csv
│   ├── vendors.csv
│   ├── properties.csv
│   ├── enquiries.csv
│   ├── viewings.csv
│   ├── offers.csv
│   ├── communications.csv
│   ├── marketing_campaigns.csv
│   ├── financial_qualifications.csv
│   ├── buyer_requirements.csv
│   ├── workflow_paths.csv
│   ├── sub_tasks.csv
│   └── agent_executions.csv
│
└── Stage_2\
    ├── stage2_valuations.csv
    ├── stage2_property_research.csv
    ├── stage2_cma_reports.csv
    ├── stage2_marketing_proposals.csv
    ├── stage2_valuation_visits.csv
    ├── stage2_instructions.csv
    ├── stage2_workflow_paths.csv
    ├── stage2_sub_tasks.csv
    ├── stage2_agent_executions.csv
    └── stage2_communications.csv
```

## Setup Steps

### 1. Create the folders
```cmd
cd C:\Users\mouni\uk_estate_agency_ai\data
mkdir Stage_1
mkdir Stage_2
```

### 2. Move Stage 1 files
Move all original CSV files (without "stage2_" prefix) to `Stage_1\`:
```cmd
move leads.csv Stage_1\
move buyers.csv Stage_1\
move vendors.csv Stage_1\
move properties.csv Stage_1\
move enquiries.csv Stage_1\
move viewings.csv Stage_1\
move offers.csv Stage_1\
move communications.csv Stage_1\
move marketing_campaigns.csv Stage_1\
move financial_qualifications.csv Stage_1\
move buyer_requirements.csv Stage_1\
move workflow_paths.csv Stage_1\
move sub_tasks.csv Stage_1\
move agent_executions.csv Stage_1\
```

### 3. Move Stage 2 files
Move all "stage2_" prefixed files to `Stage_2\`:
```cmd
move stage2_*.csv Stage_2\
```

## How It Works

When you run a query:

1. **Orchestrator analyzes** your query to determine which stages are needed

2. **Stage detection based on keywords:**
   - Stage 1 keywords: `lead`, `buyer`, `qualify`, `enquiry`, `portal`, `rightmove`
   - Stage 2 keywords: `valuation`, `cma`, `instruction`, `pricing`, `fee`

3. **Data loading:**
   - If Stage 1 tasks → loads from `data/Stage_1/`
   - If Stage 2 tasks → loads from `data/Stage_2/`
   - Shared tables (vendors, properties, buyers) available to both

4. **Multi-stage queries** load data from both folders automatically

## Example Queries

### Stage 1 Only:
- "Process new lead from Jessica Turner"
- "Qualify buyer BUY-001"

### Stage 2 Only:
- "Generate CMA for valuation VAL-001"
- "Process instruction signing"

### Multi-Stage (both):
- "I have a new seller who wants to sell. Help me qualify the lead, research the property, and get the instruction signed."

## Verification

After setup, restart server and check:
```
http://localhost:8000/api/data/summary
```

Should show:
```json
{
  "stage_1": {"tables": {...}, "total_records": 250},
  "stage_2": {"tables": {...}, "total_records": 140},
  "total_records": 390
}
```
