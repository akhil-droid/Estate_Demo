"""
FastAPI Routes for UK Estate Agency AI System
Enhanced with Stage-Aware Data Loading
"""

import asyncio
import json
import time
from typing import Dict, List, Optional
from queue import Queue
from threading import Thread, Event

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from agents import EstateAgencyOrchestrator, AgentStep
from data_loader import (
    load_all_data, 
    get_data_for_stage, 
    get_data_for_subtask,
    get_data_summary,
    EXAMPLE_QUERIES
)
from config import AGENT_CONFIG, STAGES, DATA_DIR

# ============================================================================
# ROUTER
# ============================================================================

router = APIRouter(prefix="/api", tags=["API"])

# ============================================================================
# GLOBAL STATE
# ============================================================================

ALL_DATA: Dict = {}  # Stores all stage data
sessions: Dict[str, Dict] = {}

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class QueryRequest(BaseModel):
    query: str

class PlanRequest(BaseModel):
    plan: Dict

class CheckpointResponse(BaseModel):
    session_id: str
    response: str

# ============================================================================
# STAGE DEFINITIONS
# ============================================================================

STAGE_DEFINITIONS = {
    1: {
        "name": "Lead Generation & Customer Acquisition",
        "sub_stages": [
            {
                "id": "1.1",
                "name": "Vendor Lead Generation",
                "sub_tasks": [
                    {"id": "1.1.1", "name": "Inbound Lead Capture", "ai_pct": 20, "checkpoint": False},
                    {"id": "1.1.2", "name": "Outbound Prospecting", "ai_pct": 15, "checkpoint": False},
                    {"id": "1.1.3", "name": "Marketing & Brand Building", "ai_pct": 40, "checkpoint": False},
                    {"id": "1.1.4", "name": "Database Reactivation", "ai_pct": 50, "checkpoint": False},
                ]
            },
            {
                "id": "1.2",
                "name": "Buyer Lead Generation",
                "sub_tasks": [
                    {"id": "1.2.1", "name": "Portal Enquiry Management", "ai_pct": 30, "checkpoint": False},
                    {"id": "1.2.2", "name": "Website Lead Capture", "ai_pct": 30, "checkpoint": False},
                    {"id": "1.2.3", "name": "Walk-ins & Direct Contact", "ai_pct": 15, "checkpoint": False},
                ]
            },
            {
                "id": "1.3",
                "name": "Lead Qualification",
                "sub_tasks": [
                    {"id": "1.3.1", "name": "Buyer Registration Process", "ai_pct": 25, "checkpoint": False},
                    {"id": "1.3.2", "name": "Buyer Financial Qualification", "ai_pct": 20, "checkpoint": True, "checkpoint_msg": "Financial qualification complete. Proceed with this lead?"},
                    {"id": "1.3.3", "name": "Buyer Requirements Matching", "ai_pct": 70, "checkpoint": False},
                ]
            }
        ]
    },
    2: {
        "name": "Valuation Appointment",
        "sub_stages": [
            {
                "id": "2.1",
                "name": "Pre-Valuation Research",
                "sub_tasks": [
                    {"id": "2.1.1", "name": "Property Research", "ai_pct": 70, "checkpoint": False},
                    {"id": "2.1.2", "name": "CMA Preparation", "ai_pct": 80, "checkpoint": False},
                    {"id": "2.1.3", "name": "Marketing Proposal", "ai_pct": 60, "checkpoint": True, "checkpoint_msg": "Pre-valuation preparation complete. Ready to proceed to appointment?"},
                ]
            },
            {
                "id": "2.2",
                "name": "Valuation Visit",
                "sub_tasks": [
                    {"id": "2.2.1", "name": "Property Tour & Assessment", "ai_pct": 5, "checkpoint": False},
                    {"id": "2.2.2", "name": "Rapport Building", "ai_pct": 0, "checkpoint": False},
                    {"id": "2.2.3", "name": "Market Update Presentation", "ai_pct": 40, "checkpoint": False},
                    {"id": "2.2.4", "name": "Pricing Presentation", "ai_pct": 30, "checkpoint": False},
                    {"id": "2.2.5", "name": "Marketing Plan Presentation", "ai_pct": 20, "checkpoint": False},
                    {"id": "2.2.6", "name": "Fee Negotiation", "ai_pct": 10, "checkpoint": False},
                    {"id": "2.2.7", "name": "Close Instruction", "ai_pct": 15, "checkpoint": True, "checkpoint_msg": "Has the vendor signed the instruction?"},
                ]
            },
            {
                "id": "2.3",
                "name": "Post-Valuation",
                "sub_tasks": [
                    {"id": "2.3.1", "name": "Thank You Communication", "ai_pct": 90, "checkpoint": False},
                    {"id": "2.3.2", "name": "Follow-up Call/Email", "ai_pct": 30, "checkpoint": False},
                ]
            }
        ]
    }
}

# ============================================================================
# AGENT TO SUBTASK MAPPING
# ============================================================================

AGENT_MAP = {
    # Stage 1
    "1.1.1": ("Scout", "🔍", "Capturing inbound lead from website/phone"),
    "1.1.2": ("Scout", "🔍", "Processing outbound prospecting activity"),
    "1.1.3": ("Content", "✍️", "Generating marketing content"),
    "1.1.4": ("Comms", "📧", "Sending reactivation emails to dormant leads"),
    "1.2.1": ("Scout", "🔍", "Processing portal enquiry from Rightmove/Zoopla"),
    "1.2.2": ("Scout", "🔍", "Capturing website lead"),
    "1.2.3": ("Scout", "🔍", "Registering walk-in contact"),
    "1.3.1": ("Intelligence", "🧠", "Creating buyer profile and registration"),
    "1.3.2": ("Compliance", "✅", "Verifying financial status and AIP"),
    "1.3.3": ("Intelligence", "🧠", "Running buyer-property matching algorithm"),
    # Stage 2
    "2.1.1": ("Scout", "🔍", "Pulling Land Registry, EPC, sold prices data"),
    "2.1.2": ("Intelligence", "🧠", "Generating CMA with pricing recommendation"),
    "2.1.3": ("Content", "✍️", "Creating marketing proposal package"),
    "2.2.1": ("Scout", "🔍", "Recording property tour assessment notes"),
    "2.2.2": ("Intelligence", "🧠", "Logging rapport building notes"),
    "2.2.3": ("Intelligence", "🧠", "Presenting local market data and trends"),
    "2.2.4": ("Valuator", "📊", "Presenting pricing with CMA evidence"),
    "2.2.5": ("Content", "✍️", "Presenting marketing plan options"),
    "2.2.6": ("Intelligence", "🧠", "Handling fee negotiation discussion"),
    "2.2.7": ("Compliance", "✅", "Processing instruction signing and compliance"),
    "2.3.1": ("Comms", "📧", "Sending personalized thank you communication"),
    "2.3.2": ("Comms", "📧", "Conducting follow-up call or email"),
}

# ============================================================================
# DATA INITIALIZATION
# ============================================================================

def initialize_data(data_dir: str = None):
    """Initialize all mock data from stage folders"""
    global ALL_DATA
    ALL_DATA = load_all_data(data_dir or DATA_DIR)
    return ALL_DATA

# ============================================================================
# PLANNING ENDPOINT
# ============================================================================

@router.post("/plan")
async def create_plan(request: QueryRequest):
    """Analyze query and create execution plan with stage-aware data"""
    query = request.query.lower()
    
    # Determine which stages are needed
    stages_needed = []
    
    # Stage 1 keywords
    if any(word in query for word in ["lead", "qualify", "buyer", "enquiry", "portal", "rightmove", "zoopla", "registration", "financial", "aip", "matching"]):
        stages_needed.append(1)
    
    # Stage 2 keywords
    if any(word in query for word in ["valuation", "visit", "cma", "instruction", "signed", "schedule", "research", "property research", "marketing proposal", "fee", "pricing", "thank you", "follow up"]):
        stages_needed.append(2)
    
    # If seller/vendor mentioned with property, likely need both stages
    if any(word in query for word in ["seller", "vendor"]) and any(word in query for word in ["property", "house", "home"]):
        if 1 not in stages_needed:
            stages_needed.append(1)
        if 2 not in stages_needed:
            stages_needed.append(2)
    
    if not stages_needed:
        stages_needed = [1]
    
    stages_needed.sort()
    
    # Build plan
    plan_stages = []
    all_sub_tasks = []
    
    for stage_num in stages_needed:
        if stage_num not in STAGE_DEFINITIONS:
            continue
        
        stage_def = STAGE_DEFINITIONS[stage_num]
        sub_stages = []
        stage_tasks = []
        
        for ss in stage_def["sub_stages"]:
            sub_stages.append({
                "id": ss["id"],
                "name": ss["name"],
                "sub_tasks": ss["sub_tasks"]
            })
            stage_tasks.extend(ss["sub_tasks"])
            all_sub_tasks.extend(ss["sub_tasks"])
        
        # Get stage-specific data summary
        stage_data = get_data_for_stage(ALL_DATA, stage_num)
        data_summary = {k: len(v) for k, v in stage_data.items()}
        
        plan_stages.append({
            "stage": stage_num,
            "name": stage_def["name"],
            "sub_stages": sub_stages,
            "sub_tasks": stage_tasks,
            "data_available": data_summary
        })
    
    # Estimated time: ~12-15 seconds per task (orchestrator + agent + data + AI processing)
    estimated_time_per_task = 12000  # 12 seconds average
    
    summary = f"I'll help you with this scenario. The plan involves {len(stages_needed)} stage(s) and {len(all_sub_tasks)} tasks. Each stage will use its specific mock data. Review the plan on the right and approve to start execution."
    
    return {
        "success": True,
        "plan": {
            "query": request.query,
            "summary": summary,
            "stages": plan_stages,
            "total_stages": len(stages_needed),
            "total_tasks": len(all_sub_tasks),
            "estimated_time_ms": len(all_sub_tasks) * estimated_time_per_task
        }
    }

# ============================================================================
# EXECUTION ENDPOINT
# ============================================================================

@router.post("/execute")
async def execute_plan(request: PlanRequest):
    """Start plan execution"""
    session_id = f"session_{int(time.time() * 1000)}"
    
    sessions[session_id] = {
        "queue": Queue(),
        "checkpoint_event": Event(),
        "checkpoint_response": None,
        "plan": request.plan
    }
    
    def run_execution():
        import asyncio
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(execute_plan_async(session_id, request.plan))
        finally:
            loop.close()
    
    thread = Thread(target=run_execution)
    thread.start()
    
    return {"session_id": session_id, "status": "started"}


async def execute_plan_async(session_id: str, plan: Dict):
    """Execute the plan with stage-aware data - realistic AI timing"""
    session = sessions.get(session_id)
    if not session:
        return
    
    queue = session["queue"]
    total_start = time.time()
    stages_completed = 0
    
    # Create orchestrator
    orchestrator = EstateAgencyOrchestrator()
    
    for stage in plan.get("stages", []):
        stage_num = stage["stage"]
        
        # Get stage-specific data
        stage_data = get_data_for_stage(ALL_DATA, stage_num)
        orchestrator.load_data(stage_data)
        
        # ==========================================
        # STAGE INITIALIZATION (2-3 seconds)
        # ==========================================
        queue.put({
            "type": "stage_start",
            "data": {
                "stage": stage_num, 
                "name": stage["name"],
                "data_tables": list(stage_data.keys()),
                "message": f"Initializing Stage {stage_num} environment..."
            }
        })
        
        await asyncio.sleep(1.5)
        
        # Show data loading step
        queue.put({
            "type": "step",
            "data": {
                "agent": "Orchestrator",
                "agent_icon": "🎯",
                "message": f"Connecting to Stage {stage_num} database...",
                "status": "running",
                "time_ms": 0
            }
        })
        
        await asyncio.sleep(2.0)
        
        total_records = sum(len(v) for v in stage_data.values())
        queue.put({
            "type": "step",
            "data": {
                "agent": "Orchestrator",
                "agent_icon": "🎯",
                "message": f"✓ Loaded {len(stage_data)} tables with {total_records} records",
                "status": "complete",
                "time_ms": 2000
            }
        })
        
        await asyncio.sleep(1.0)
        
        # ==========================================
        # SUB-STAGES LOOP
        # ==========================================
        for sub_stage in stage.get("sub_stages", []):
            queue.put({
                "type": "substage_start",
                "data": {"id": sub_stage["id"], "name": sub_stage["name"]}
            })
            
            await asyncio.sleep(1.2)
            
            # ==========================================
            # SUB-TASKS LOOP (8-15 seconds per task)
            # ==========================================
            for sub_task in sub_stage.get("sub_tasks", []):
                queue.put({
                    "type": "subtask_start",
                    "data": {"id": sub_task["id"], "name": sub_task["name"]}
                })
                
                start_time = time.time()
                task_id = sub_task["id"]
                task_name = sub_task["name"]
                ai_pct = sub_task.get("ai_pct", 50)
                
                # Get agent info
                agent_info = AGENT_MAP.get(task_id, ("Intelligence", "🧠", "Processing task"))
                
                # ------------------------------------------
                # STEP 1: Orchestrator Analysis (2 seconds)
                # ------------------------------------------
                queue.put({
                    "type": "step",
                    "data": {
                        "agent": "Orchestrator",
                        "agent_icon": "🎯",
                        "message": f"Analyzing task requirements for {task_id}...",
                        "status": "running",
                        "time_ms": 0
                    }
                })
                
                await asyncio.sleep(2.0)
                
                queue.put({
                    "type": "step",
                    "data": {
                        "agent": "Orchestrator",
                        "agent_icon": "🎯",
                        "message": f"Delegating to {agent_info[0]} Agent ({ai_pct}% AI automation)",
                        "status": "complete",
                        "time_ms": 2000
                    }
                })
                
                await asyncio.sleep(1.0)
                
                # ------------------------------------------
                # STEP 2: Agent Starting Work (1.5 seconds)
                # ------------------------------------------
                queue.put({
                    "type": "step",
                    "data": {
                        "agent": agent_info[0],
                        "agent_icon": agent_info[1],
                        "message": f"Initializing {task_name}...",
                        "status": "running",
                        "time_ms": 0
                    }
                })
                
                await asyncio.sleep(1.5)
                
                # ------------------------------------------
                # STEP 3: Data Query (2-3 seconds)
                # ------------------------------------------
                data_used = get_data_tables_for_task(task_id, stage_num)
                
                if data_used:
                    queue.put({
                        "type": "step",
                        "data": {
                            "agent": "Scout",
                            "agent_icon": "🔍",
                            "message": f"Querying: {', '.join(data_used)}...",
                            "status": "running",
                            "time_ms": 0
                        }
                    })
                    
                    await asyncio.sleep(2.5)
                    
                    # Show record counts
                    data_counts = {t: len(stage_data.get(t, [])) for t in data_used}
                    queue.put({
                        "type": "step",
                        "data": {
                            "agent": "Scout",
                            "agent_icon": "🔍",
                            "message": f"✓ Retrieved {sum(data_counts.values())} records from {len(data_used)} tables",
                            "status": "complete",
                            "time_ms": 2500
                        }
                    })
                    
                    await asyncio.sleep(0.8)
                
                # ------------------------------------------
                # STEP 4: AI Processing (3-6 seconds based on AI %)
                # ------------------------------------------
                if ai_pct > 20:
                    queue.put({
                        "type": "step",
                        "data": {
                            "agent": agent_info[0],
                            "agent_icon": agent_info[1],
                            "message": f"Running AI analysis ({ai_pct}% automation)...",
                            "status": "running",
                            "time_ms": 0
                        }
                    })
                    
                    # Higher AI % = longer processing
                    ai_delay = 2.0 + (ai_pct / 100) * 4.0
                    await asyncio.sleep(ai_delay)
                    
                    queue.put({
                        "type": "step",
                        "data": {
                            "agent": agent_info[0],
                            "agent_icon": agent_info[1],
                            "message": f"✓ AI processing complete - generating output",
                            "status": "complete",
                            "time_ms": int(ai_delay * 1000)
                        }
                    })
                    
                    await asyncio.sleep(0.8)
                
                # ------------------------------------------
                # STEP 5: Task-Specific Action (2-3 seconds)
                # ------------------------------------------
                action_message = get_action_message(task_id, task_name, stage_data)
                
                queue.put({
                    "type": "step",
                    "data": {
                        "agent": agent_info[0],
                        "agent_icon": agent_info[1],
                        "message": action_message,
                        "status": "running",
                        "time_ms": 0
                    }
                })
                
                await asyncio.sleep(2.5)
                
                # ------------------------------------------
                # STEP 6: Completion (1 second)
                # ------------------------------------------
                completion_message = get_completion_message(task_id, task_name, stage_data)
                
                queue.put({
                    "type": "step",
                    "data": {
                        "agent": agent_info[0],
                        "agent_icon": agent_info[1],
                        "message": f"✓ {completion_message}",
                        "status": "complete",
                        "time_ms": int((time.time() - start_time) * 1000),
                        "data_used": data_used
                    }
                })
                
                await asyncio.sleep(1.0)
                
                queue.put({
                    "type": "subtask_complete",
                    "data": {"id": sub_task["id"]}
                })
                
                # ------------------------------------------
                # CHECKPOINT (if required)
                # ------------------------------------------
                if sub_task.get("checkpoint"):
                    await asyncio.sleep(0.5)
                    
                    queue.put({
                        "type": "checkpoint",
                        "data": {
                            "title": "🛑 Human Review Required",
                            "message": sub_task.get("checkpoint_msg", "Please confirm to proceed."),
                            "subtask_id": sub_task["id"]
                        }
                    })
                    
                    session["checkpoint_event"].clear()
                    session["checkpoint_event"].wait(timeout=300)
                    
                    if session.get("checkpoint_response") == "no":
                        queue.put({
                            "type": "complete",
                            "data": {
                                "status": "cancelled",
                                "total_time_ms": int((time.time() - total_start) * 1000),
                                "stages_completed": stages_completed
                            }
                        })
                        return
                    
                    # Acknowledge approval
                    queue.put({
                        "type": "step",
                        "data": {
                            "agent": "Orchestrator",
                            "agent_icon": "🎯",
                            "message": "✓ Human approval received - continuing workflow",
                            "status": "complete",
                            "time_ms": 0
                        }
                    })
                    
                    await asyncio.sleep(1.5)
                
                # Pause between tasks
                await asyncio.sleep(2.0)
        
        # ==========================================
        # STAGE COMPLETION
        # ==========================================
        queue.put({
            "type": "step",
            "data": {
                "agent": "Orchestrator",
                "agent_icon": "🎯",
                "message": f"✓ Stage {stage_num} complete - {len(stage.get('sub_stages', []))} sub-stages processed",
                "status": "complete",
                "time_ms": int((time.time() - total_start) * 1000)
            }
        })
        
        await asyncio.sleep(1.0)
        
        queue.put({
            "type": "stage_complete",
            "data": {"stage": stage_num}
        })
        stages_completed += 1
        
        await asyncio.sleep(2.5)  # Pause between stages
    
    # ==========================================
    # WORKFLOW COMPLETE
    # ==========================================
    queue.put({
        "type": "step",
        "data": {
            "agent": "Orchestrator",
            "agent_icon": "🎯",
            "message": f"🎉 Workflow complete! {stages_completed} stage(s) executed successfully",
            "status": "complete",
            "time_ms": int((time.time() - total_start) * 1000)
        }
    })
    
    await asyncio.sleep(1.0)
    
    queue.put({
        "type": "complete",
        "data": {
            "status": "success",
            "total_time_ms": int((time.time() - total_start) * 1000),
            "stages_completed": stages_completed
        }
    })


def get_data_tables_for_task(task_id: str, stage_num: int) -> List[str]:
    """Get the data tables used by a specific task"""
    if stage_num == 1:
        if task_id.startswith("1.1"):
            return ["leads", "vendors"]
        elif task_id.startswith("1.2"):
            return ["enquiries", "buyers"]
        elif task_id.startswith("1.3"):
            return ["buyers", "financial_qualifications", "buyer_requirements", "properties"]
    elif stage_num == 2:
        if task_id == "2.1.1":
            return ["valuations", "property_research", "properties"]
        elif task_id == "2.1.2":
            return ["valuations", "cma_reports", "property_research"]
        elif task_id == "2.1.3":
            return ["valuations", "marketing_proposals"]
        elif task_id.startswith("2.2"):
            return ["valuations", "valuation_visits", "vendors"]
        elif task_id.startswith("2.3"):
            return ["valuations", "communications"]
    return []


def get_action_message(task_id: str, task_name: str, stage_data: Dict) -> str:
    """Get a specific action message for a task"""
    messages = {
        # Stage 1
        "1.1.1": "Capturing lead details and creating vendor record...",
        "1.1.2": "Logging outbound prospecting activity and outcomes...",
        "1.1.3": "Generating marketing content and campaign materials...",
        "1.1.4": "Scanning dormant leads and preparing reactivation emails...",
        "1.2.1": "Processing portal enquiry and matching to properties...",
        "1.2.2": "Capturing website lead and verifying contact details...",
        "1.2.3": "Registering walk-in visitor and collecting requirements...",
        "1.3.1": "Creating buyer profile with preferences and timeline...",
        "1.3.2": "Verifying AIP/mortgage status and financial position...",
        "1.3.3": "Running matching algorithm against property database...",
        # Stage 2
        "2.1.1": "Pulling Land Registry, EPC, and sold price data...",
        "2.1.2": "Analyzing comparables and generating price recommendation...",
        "2.1.3": "Building marketing package with photography options...",
        "2.2.1": "Recording property condition and features assessment...",
        "2.2.2": "Logging vendor rapport and relationship notes...",
        "2.2.3": "Compiling local market statistics and trends...",
        "2.2.4": "Presenting pricing evidence with CMA comparables...",
        "2.2.5": "Displaying marketing package options and costs...",
        "2.2.6": "Processing fee discussion and negotiation points...",
        "2.2.7": "Verifying compliance and preparing contract documents...",
        "2.3.1": "Generating personalized thank you message...",
        "2.3.2": "Preparing follow-up communication and next steps...",
    }
    return messages.get(task_id, f"Executing {task_name}...")


def get_completion_message(task_id: str, task_name: str, stage_data: Dict) -> str:
    """Get a completion message with data context"""
    messages = {
        # Stage 1
        "1.1.1": "Lead captured and vendor record created",
        "1.1.2": "Prospecting activity logged successfully",
        "1.1.3": "Marketing content generated and ready",
        "1.1.4": "Reactivation emails queued for sending",
        "1.2.1": "Portal enquiry processed and buyer notified",
        "1.2.2": "Website lead captured with verification sent",
        "1.2.3": "Walk-in registered with requirements documented",
        "1.3.1": "Buyer profile created with full preferences",
        "1.3.2": "Financial qualification verified - status confirmed",
        "1.3.3": "Matching complete - suitable properties identified",
        # Stage 2
        "2.1.1": "Property research dossier complete (95% data found)",
        "2.1.2": "CMA report generated with pricing recommendation",
        "2.1.3": "Marketing proposal ready for presentation",
        "2.2.1": "Property assessment recorded with photos",
        "2.2.2": "Rapport notes logged - relationship established",
        "2.2.3": "Market update delivered with current data",
        "2.2.4": "Pricing presented with evidence - vendor response logged",
        "2.2.5": "Marketing plan presented and options discussed",
        "2.2.6": "Fee negotiation complete - terms agreed",
        "2.2.7": "Instruction processed - compliance checks passed",
        "2.3.1": "Thank you communication sent successfully",
        "2.3.2": "Follow-up scheduled and reminders set",
    }
    return messages.get(task_id, f"{task_name} completed successfully")

# ============================================================================
# CHECKPOINT ENDPOINT
# ============================================================================

@router.post("/checkpoint")
async def handle_checkpoint(request: CheckpointResponse):
    """Handle human checkpoint response"""
    session = sessions.get(request.session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    session["checkpoint_response"] = request.response
    session["checkpoint_event"].set()
    
    return {"status": "received", "response": request.response}

# ============================================================================
# SSE STREAM
# ============================================================================

@router.get("/stream/{session_id}")
async def stream_events(session_id: str):
    """SSE endpoint for real-time execution updates"""
    session = sessions.get(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    
    async def event_generator():
        queue = session["queue"]
        timeout_count = 0
        
        while timeout_count < 600:
            if not queue.empty():
                event = queue.get()
                event_type = event.get("type", "message")
                event_data = json.dumps(event.get("data", {}))
                
                yield f"event: {event_type}\ndata: {event_data}\n\n"
                
                if event_type == "complete":
                    if session_id in sessions:
                        del sessions[session_id]
                    break
                
                timeout_count = 0
            else:
                timeout_count += 1
                yield f": keepalive\n\n"
            
            await asyncio.sleep(0.1)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )

# ============================================================================
# OTHER ENDPOINTS
# ============================================================================

@router.get("/health")
async def health_check():
    return {"status": "healthy", "data_loaded": len(ALL_DATA) > 0}

@router.get("/agents")
async def get_agents():
    return {"agents": [{"id": k, **v} for k, v in AGENT_CONFIG.items()]}

@router.get("/stages")
async def get_stages():
    return {"stages": [
        {"id": k, "name": v["name"], "enabled": v["enabled"]}
        for k, v in STAGES.items()
    ]}

@router.get("/data/summary")
async def get_data_summary_endpoint():
    return get_data_summary(ALL_DATA)

@router.get("/data/stage/{stage_num}")
async def get_stage_data_summary(stage_num: int):
    """Get data summary for a specific stage"""
    stage_data = get_data_for_stage(ALL_DATA, stage_num)
    return {
        "stage": stage_num,
        "tables": {k: len(v) for k, v in stage_data.items()},
        "total_records": sum(len(v) for v in stage_data.values())
    }

@router.get("/examples")
async def get_all_examples():
    """Get example queries for all stages"""
    return {"examples": EXAMPLE_QUERIES}

@router.get("/examples/{sub_task_id}")
async def get_subtask_examples(sub_task_id: str):
    """Get example queries for a specific sub-task"""
    examples = EXAMPLE_QUERIES.get(sub_task_id, [])
    return {"sub_task": sub_task_id, "examples": examples}
